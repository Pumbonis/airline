# Animate table rows - UI Animations Workshop

A Pen created on CodePen.io. Original URL: [https://codepen.io/sandstedt/pen/wvejaXY](https://codepen.io/sandstedt/pen/wvejaXY).

